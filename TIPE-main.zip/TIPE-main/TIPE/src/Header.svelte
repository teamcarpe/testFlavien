<script>
let src = '\Cleanum.png';
let axel = '\Photo Axel.png';
let flavien = '\Photo Flavien.png';


</script>

<main>
    <button class="contact" style="font">Contacts</button>
    <!-- svelte-ignore a11y-img-redundant-alt -->
    <img {src} alt="" width="180" height="150"/>
    <div class="rec"></div>
    <h1>Cleanum</h1>
    <p class="text">3 étudiants en CUPGE à l’ESIR</p>
    <p class="text2" >Site web de sensibilisation de la population sur la pollution numérique et l’impact de chacun.</p>
    <div class="rec2"></div>
    <h2>Que puis-je faire ?</h2>
    <p class="text3">
        Informez-vous sur le sujet en vous baladant sur le site.<br>
        
        Simulez votre impact sur la pollution !<br>
        
        Prenez conscience, agissez ! </p>
    <h3>Notre équipe</h3>
    <p class="text4">Des jeunes passionés par l’écologie et l’informatique.</p>
    <p class="text5">Axel Allain &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Flavien Lebret</p>
    <img {axel} alt="" width="180" height="150" />
    <img {flavien} alt="" width="180" height="150"/>
        <div class="rec3"></div>
    <button class="simulation">Simulation</button>
</main>

<style>
    @import url('https://fonts.googleapis.com/css2?family=Jost&display=swap');
	
    .contact{
        position: absolute;
        width: 130px;
        height: 55px;
        left: 1135px;
        top: 56px;
         font-family: 'Jost';
         font-weight: bold;
         font-size: 18px;
        border: 2px solid #000000;
        box-sizing: border-box;
        border-radius: 20px;
        background-color:  #F0F3F9;
        cursor:pointer;
    }
    .rec{
        position: absolute;
        width: 1100px;
        height: 550px;
        left: 117px;
        top: 204px;

        background: linear-gradient(90deg, #82A0D5 0%, #8BA1DB 11.11%, #95A1E0 22.22%, #A0A1E4 33.33%, #ACA0E7 44.44%, #B9A0E9 55.56%, #C69FEA 66.67%, #D39DE9 77.78%, #E19CE8 88.89%, #EE9AE5 100%), #C4C4C4;
        border-radius: 70px 70px 300px 70px;
    }
    .rec2{
        position: absolute;
        width: 1100px;
        height: 550px;
        left: 117px;
        top: 1000px;

        background: linear-gradient(90deg, #82A0D5 0%, #8BA1DB 11.11%, #95A1E0 22.22%, #A0A1E4 33.33%, #ACA0E7 44.44%, #B9A0E9 55.56%, #C69FEA 66.67%, #D39DE9 77.78%, #E19CE8 88.89%, #EE9AE5 100%), #C4C4C4;
        border-radius: 70px 70px 300px 70px;
    }
    .rec3{
        position: absolute;
        width: 1202px;
        height: 626px;
        left: 119px;
        top: 2200px;

        background: linear-gradient(90deg, #82A0D5 0%, #8BA1DB 11.11%, #95A1E0 22.22%, #A0A1E4 33.33%, #ACA0E7 44.44%, #B9A0E9 55.56%, #C69FEA 66.67%, #D39DE9 77.78%, #E19CE8 88.89%, #EE9AE5 100%), #C4C4C4;
        border-radius: 70px 300px 300px 300px;
    }
    h1{
        position: absolute;
        width: 862px;
        height: 193px;
        left: 43px;
        top: 160px;

        font-family: 'Jost';
        font-style: normal;
        font-weight: bold;
        font-size: 144px;
        line-height: 208px;
        text-align: center;

        color: #000000;
    }

    h2{
        position: absolute;
        width: 862px;
        height: 193px;
        left: 200px;
        top: 900px;

        font-family: 'Jost';
        font-style: normal;
        font-weight: bold;
        font-size: 100px;
        line-height: 208px;
        text-align: center;

        color: #000000;
    }

    .text{
        position: absolute;
        width: 478px;
        height: 50px;
        left: 242px;
        top: 460px;

        font-family: 'Jost';
        font-weight: bold;
        font-size: 30px;
    }
    .text2{
        position: absolute;
        width: 478px;
        height: 50px;
        left: 242px;
        top: 570px;

        font-family: 'Jost';
        font-weight: bold;
        font-size: 25px;
    }
    .text3{
        position: absolute;
        width: 700px;
        height: 50px;
        left: 242px;
        top: 1175px;

        font-family: 'Jost';
        font-weight: bold;
        font-size: 30px;
        line-height: 100px;
        text-align: center;
    }
    h3{
        position: absolute;
        width: 478px;
        height: 50px;
        left: 180px;
        top: 1700px;

        font-family: 'Jost';
        font-weight: bold;
        font-size: 60px;
    }
    .text4{
        position: absolute;
        width: 478px;
        height: 50px;
        left: 180px;
        top: 1865px;

        font-family: 'Jost';
        font-weight: bold;
        font-size: 30px;
    }
    .text5{
        position: absolute;
        width: 478px;
        height: 50px;
        left: 800px;
        top: 2000px;

        font-family: 'Jost';
        font-weight: bold;
        font-size: 30px;
    }
    .simulation{
    position: absolute;
    cursor:pointer;
    width: 369px;
    height: 344px;
    left: 530px;
    top: 2350px;
    font-family: 'Jost';
    font-weight:bolder;
    font-size: 50px;

    border: 14px solid #000000;
    background:  linear-gradient(90deg, #82A0D5 0%, #8BA1DB 11.11%, #95A1E0 22.22%, #A0A1E4 33.33%, #ACA0E7 44.44%, #B9A0E9 55.56%, #C69FEA 66.67%, #D39DE9 77.78%, #E19CE8 88.89%, #EE9AE5 100%), #C4C4C4;;
    box-sizing: border-box;
    border-radius: 50%;
    filter: drop-shadow(-76.5486px 51.0324px 89px rgba(0, 0, 0, 0.47)) drop-shadow(-49.6148px 33.0766px 52.1227px rgba(0, 0, 0, 0.356852)) drop-shadow(-29.4854px 19.6569px 28.3481px rgba(0, 0, 0, 0.285481)) drop-shadow(-15.3097px 10.2065px 14.4625px rgba(0, 0, 0, 0.235)) drop-shadow(-6.2373px 4.1582px 7.25185px rgba(0, 0, 0, 0.184519)) drop-shadow(-1.41757px 0.945045px 3.50231px rgba(0, 0, 0, 0.113148));
    }

    
</style>